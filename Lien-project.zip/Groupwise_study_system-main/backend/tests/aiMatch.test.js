import { describe, it } from "node:test";
import assert from "node:assert/strict";

import { profileCompleteness, sanitiseMatches } from "../src/lib/aiMatchRules.js";

const shortlist = [
  { groupId: "g1", name: "Databases Revision" },
  { groupId: "g2", name: "Auditing Study Circle" },
  { groupId: "g3", name: "Networks Lab Group" },
];

describe("AI group matching: sanitiseMatches", () => {
  it("keeps only groups that were on the shortlist", () => {
    const parsed = {
      matches: [
        { groupId: "g2", fitScore: 90, reason: "Same course." },
        { groupId: "invented-group", fitScore: 99, reason: "Made up." },
      ],
    };
    const result = sanitiseMatches(parsed, shortlist, 5);
    assert.deepEqual(result.map((match) => match.groupId), ["g2"]);
  });

  it("drops duplicates and respects the limit and order", () => {
    const parsed = {
      matches: [
        { groupId: "g3", fitScore: 80, reason: "a" },
        { groupId: "g3", fitScore: 70, reason: "duplicate" },
        { groupId: "g1", fitScore: 60, reason: "b" },
        { groupId: "g2", fitScore: 50, reason: "c" },
      ],
    };
    const result = sanitiseMatches(parsed, shortlist, 2);
    assert.deepEqual(result.map((match) => match.groupId), ["g3", "g1"]);
  });

  it("clamps scores and trims over-long text", () => {
    const parsed = {
      matches: [{ groupId: "g1", fitScore: 250, reason: "x".repeat(900), caution: "y".repeat(900) }],
    };
    const [match] = sanitiseMatches(parsed, shortlist, 5);
    assert.equal(match.aiScore, 100);
    assert.ok(match.aiReason.length <= 320);
    assert.ok(match.aiCaution.length <= 200);
  });

  it("returns nothing for malformed output instead of throwing", () => {
    assert.deepEqual(sanitiseMatches({}, shortlist, 5), []);
    assert.deepEqual(sanitiseMatches({ matches: "nope" }, shortlist, 5), []);
    assert.deepEqual(sanitiseMatches(null, shortlist, 5), []);
  });

  it("treats a non-numeric score as unknown rather than zero", () => {
    const [match] = sanitiseMatches({ matches: [{ groupId: "g1", fitScore: "high", reason: "ok" }] }, shortlist, 5);
    assert.equal(match.aiScore, null);
  });
});

describe("AI group matching: profileCompleteness", () => {
  const empty = { courses: [], topics: [], goals: [], availability: [], preferences: null, bio: null };

  it("reports an empty profile as 0% with every item missing", () => {
    const result = profileCompleteness(empty);
    assert.equal(result.percent, 0);
    assert.equal(result.missing.length, 6);
  });

  it("reports a full profile as 100% with nothing missing", () => {
    const result = profileCompleteness({
      courses: ["IS101 Information Systems"],
      topics: [{}, {}],
      goals: ["Exam preparation"],
      availability: ["Monday 18:00-20:00"],
      preferences: { mode: "ONLINE" },
      bio: "I study best in the evening.",
    });
    assert.equal(result.percent, 100);
    assert.deepEqual(result.missing, []);
  });

  it("asks for a second topic rating when only one is given", () => {
    const result = profileCompleteness({ ...empty, topics: [{}] });
    assert.ok(result.missing.some((item) => item.key === "topics"));
  });
});
