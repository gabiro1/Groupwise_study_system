import env from "../config/env.js";
import { AiUnavailableError, AppError } from "../lib/errors.js";

/**
 * Single transport for every AI call in Lien.
 *
 * Provider-specific details live here and nowhere else, so the parsing, chat and
 * matching code stays provider-neutral. Supported providers:
 *
 *   AI_PROVIDER=anthropic  Claude via the Messages API (https://api.anthropic.com)
 *   AI_PROVIDER=openai     Any OpenAI-compatible /chat/completions endpoint
 *   AI_PROVIDER=none       AI off. Callers get AiUnavailableError and degrade.
 *
 * The API key is read from the server environment only. It must never be exposed
 * to the browser, which is why the frontend talks to this backend and never to a
 * provider directly.
 */

const ANTHROPIC_VERSION = "2023-06-01";
const DEFAULT_ANTHROPIC_URL = "https://api.anthropic.com";
const DEFAULT_OPENAI_URL = "https://api.openai.com/v1";

/**
 * Send a chat request and return the assistant's text.
 *
 * @param {Array<{role:"system"|"user"|"assistant", content:string}>} messages
 * @param {{temperature?:number, maxTokens?:number, json?:boolean}} [options]
 * @returns {Promise<string>}
 */
export async function chatText(messages, options = {}) {
  if (!env.aiEnabled) throw new AiUnavailableError();

  const settings = {
    temperature: options.temperature ?? 0.2,
    maxTokens: options.maxTokens ?? env.AI_MAX_OUTPUT_TOKENS,
    json: Boolean(options.json),
  };

  if (env.AI_PROVIDER === "anthropic") return callAnthropic(messages, settings);
  if (env.AI_PROVIDER === "openai") return callOpenAiCompatible(messages, settings);

  throw new AiUnavailableError(`Unsupported AI provider: ${env.AI_PROVIDER}`);
}

async function callAnthropic(messages, { temperature, maxTokens, json }) {
  const baseUrl = (env.AI_BASE_URL ?? DEFAULT_ANTHROPIC_URL).replace(/\/$/, "");

  // The Messages API takes the system prompt as a top-level field, not as a
  // message, and requires turns to start with a user message.
  const system = messages
    .filter((message) => message.role === "system")
    .map((message) => message.content)
    .join("\n\n");

  const turns = messages
    .filter((message) => message.role !== "system")
    .map((message) => ({ role: message.role, content: message.content }));

  // When JSON is required, an instruction in the system prompt is the reliable
  // lever. `parseJson` in the callers still copes with a stray code fence.
  const systemPrompt = json
    ? `${system}\n\nRespond with a single valid JSON object and nothing else.`
    : system;

  const response = await fetch(`${baseUrl}/v1/messages`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": env.AI_API_KEY,
      "anthropic-version": ANTHROPIC_VERSION,
    },
    body: JSON.stringify({
      model: env.AI_CHAT_MODEL,
      max_tokens: maxTokens,
      temperature,
      ...(systemPrompt ? { system: systemPrompt } : {}),
      messages: turns,
    }),
    signal: AbortSignal.timeout(env.AI_TIMEOUT_MS),
  });

  if (!response.ok) await throwProviderError(response);

  const payload = await response.json();
  const text = (payload?.content ?? [])
    .filter((block) => block?.type === "text")
    .map((block) => block.text)
    .join("");

  if (!text) throw badResponse();
  return text;
}

async function callOpenAiCompatible(messages, { temperature, maxTokens, json }) {
  const baseUrl = (env.AI_BASE_URL ?? DEFAULT_OPENAI_URL).replace(/\/$/, "");

  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${env.AI_API_KEY}`,
    },
    body: JSON.stringify({
      model: env.AI_CHAT_MODEL,
      messages,
      temperature,
      max_tokens: maxTokens,
      ...(json ? { response_format: { type: "json_object" } } : {}),
    }),
    signal: AbortSignal.timeout(env.AI_TIMEOUT_MS),
  });

  if (!response.ok) await throwProviderError(response);

  const payload = await response.json();
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content !== "string" || !content) throw badResponse();
  return content;
}

async function throwProviderError(response) {
  const body = await response.text().catch(() => "");
  throw new AppError("The assistant is unavailable right now.", {
    status: 502,
    code: "AI_PROVIDER_ERROR",
    // Truncated: provider error bodies can be long and are for logs, not users.
    details: `${response.status}: ${body.slice(0, 200)}`,
  });
}

function badResponse() {
  return new AppError("The assistant returned an unusable response.", {
    status: 502,
    code: "AI_BAD_RESPONSE",
  });
}

/**
 * Pull a JSON object out of a model reply. Models sometimes wrap JSON in a code
 * fence or add a sentence of preamble; both are recoverable.
 */
export function parseJsonObject(raw) {
  const text = String(raw ?? "").trim();
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  const candidate = fenced ? fenced[1] : text;

  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1) return {};

  try {
    return JSON.parse(candidate.slice(start, end + 1));
  } catch {
    return {};
  }
}

export default { chatText, parseJsonObject };
