# Turning on Lien's AI (chat + AI group matching)

Two features use AI, and both switch on together with one setting:

- **Ask AI tab** inside a group: answers from the group's shared notes and chat.
- **AI group matching** (Dashboard → Recommended for you): reads the student's profile and picks the best groups, with a reason for each.

Without a key, Lien still works. The Ask AI tab shows a friendly "not switched on" message and matching falls back to the built-in scoring engine.

## 1. Get an API key
Create a key in the Claude Platform console (https://platform.claude.com). Copy it once and keep it secret. Never commit it to GitHub and never put it in the frontend.

## 2. Add it to the BACKEND environment
In `backend/.env` for local work, and in your backend host's environment variables for the live site:

```
AI_PROVIDER=anthropic
AI_API_KEY=sk-ant-...your key...
# optional: AI_CHAT_MODEL=claude-haiku-5-5   (default, fast and cheap)
#           AI_CHAT_MODEL=claude-sonnet-5-5  (stronger answers, costs more)
```

OpenAI instead? Use `AI_PROVIDER=openai`, `AI_API_KEY=sk-...`, and optionally `AI_CHAT_MODEL=gpt-4o-mini`.

Restart / redeploy the backend afterwards. The API refuses requests unless BOTH `AI_PROVIDER` and `AI_API_KEY` are set.

## 3. Frontend (Vercel) settings
Only these, and none of them are secret:

```
BACKEND_API_URL=https://your-backend-url        (already set if the site works)
NEXT_PUBLIC_SUPPORT_EMAIL=your-project-email    (shown in the footer; leave unset to hide it)
NEXT_PUBLIC_SITE_URL=https://your-live-domain   (for share previews)
```

## 4. Check it works
1. Sign in as a student and complete the profile (`/dashboard/profile`): courses, at least two topic ratings, a goal, free times, preferences, and a short bio.
2. Open **Recommended for you**. The banner should say "Matched by AI using your profile".
3. Open a group that has at least one shared note or message → **Ask AI** → ask about it.

If the banner says matching is "not switched on", the backend can't see `AI_PROVIDER` and `AI_API_KEY`. Check the spelling and redeploy.

## How the AI matching works (for your project paper)
1. **Shortlist (code):** hard rules (same course, group not full, joinable, not already a member) plus the weighted scoring engine produce up to 12 real candidate groups.
2. **Decision (AI):** the model receives the student's profile (no name, email or student number) and the shortlist, then chooses and orders the best groups with a plain-language reason for each.
3. **Validation (code):** any group id the model returns that was not on the shortlist is discarded, scores are clamped, and text is length-limited. If the AI is off or fails, the engine's own ranking is shown instead.

The student always decides whether to join.
