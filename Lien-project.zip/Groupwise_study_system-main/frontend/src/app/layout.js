import { Poppins } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "./ThemeProvider";

const poppins = Poppins({
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
  variable: "--font-poppins",
  subsets: ["latin"],
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://groupwise-eight.vercel.app";
const siteDescription = "Find study partners, form groups, and learn together with Lien. Fill in your profile and our AI suggests the study groups that fit you best.";

export const metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "Lien — study together", template: "%s | Lien" },
  description: siteDescription,
  applicationName: "Lien",
  icons: {
    icon: "/lien-logo.svg",
  },
  // Controls the preview card shown when the link is shared on WhatsApp, X, LinkedIn, etc.
  openGraph: {
    type: "website",
    siteName: "Lien",
    title: "Lien — study together",
    description: siteDescription,
    url: "/",
  },
  twitter: {
    card: "summary",
    title: "Lien — study together",
    description: siteDescription,
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${poppins.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col">
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
