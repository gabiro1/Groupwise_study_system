import Link from "next/link";
import { InfoPage } from "../SiteLayout";

export const metadata = {
  title: "Privacy",
  description: "What Lien collects, why, and how the AI uses it.",
};

export default function PrivacyPage() {
  return (
    <InfoPage
      eyebrow="YOUR DATA"
      title={<>Your information,<br />used with care.</>}
      lead="Lien only asks for what it needs to help you find study groups. This page explains what that is and how the AI uses it."
    >
      <section className="info-story">
        <div>
          <span className="info-overline">WHAT WE COLLECT</span>
          <h2>The details you choose to share.</h2>
        </div>
        <div>
          <p>Your account details (name, email, university and programme), the courses and topics you are studying, how confident you feel in each topic, your learning goals, the times you are free, and your study preferences. You can also add a short bio about how you like to study.</p>
          <p>You decide what goes on your profile. Sharing less simply gives the matching less to work with.</p>
        </div>
      </section>

      <section className="info-story">
        <div>
          <span className="info-overline">HOW THE AI USES IT</span>
          <h2>To suggest groups, not to judge you.</h2>
        </div>
        <div>
          <p>To suggest study groups, your profile is sent to an AI service so it can compare you with the groups that are open to you and explain why they might fit. Your name, email and student number are not sent. Only the study details above are.</p>
          <p>The AI only suggests. You always decide whether to join a group, and groups can still ask to approve new members.</p>
          <p>The group study assistant answers using notes and messages your group has already shared with each other, and nothing from groups you are not part of.</p>
        </div>
      </section>

      <section className="info-story">
        <div>
          <span className="info-overline">YOUR CHOICES</span>
          <h2>You stay in control.</h2>
        </div>
        <div>
          <p>You can edit or remove profile details at any time, change who can see your profile in your privacy settings, and leave a group whenever you like.</p>
          <p>Questions about your data? <Link href="/contact">Contact us</Link>.</p>
        </div>
      </section>
    </InfoPage>
  );
}
